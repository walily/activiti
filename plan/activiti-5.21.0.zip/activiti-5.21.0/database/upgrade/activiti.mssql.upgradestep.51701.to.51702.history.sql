alter table ACT_HI_ATTACHMENT add TIME_ datetime;
