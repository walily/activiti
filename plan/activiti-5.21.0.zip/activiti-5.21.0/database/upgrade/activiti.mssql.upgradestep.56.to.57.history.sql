alter table ACT_HI_PROCINST 
add SUPER_PROCESS_INSTANCE_ID_ nvarchar(64);
