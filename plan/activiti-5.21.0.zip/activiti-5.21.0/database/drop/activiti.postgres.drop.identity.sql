drop table if exists ACT_ID_INFO cascade;
drop table if exists ACT_ID_GROUP cascade;
drop table if exists ACT_ID_MEMBERSHIP cascade;
drop table if exists ACT_ID_USER cascade;